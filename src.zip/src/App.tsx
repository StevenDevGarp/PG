import React from 'react';
import './App.css';
import DocumentManagementSystem from './components/Document-management-system/document-management-system';



function App() {
    return (
        <div>
          <DocumentManagementSystem />
        </div>
      );
}

export default App
