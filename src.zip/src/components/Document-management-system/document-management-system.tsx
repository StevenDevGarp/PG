import { useState, useEffect } from "react"
import React from "react"
import { Button } from "../ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs"
import { BarChart, FileText, Folder, Users, Sun, Moon, FilePlus  } from "lucide-react"

export default function DocumentManagementSystem() {
  const [darkMode, setDarkMode] = useState(false)

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [darkMode])

  const toggleDarkMode = () => {
    setDarkMode(!darkMode)
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-white dark:bg-gray-800 p-4 shadow-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">D-Docs</h2>
          <Button variant="ghost" size="sm" onClick={toggleDarkMode}>
            {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
        </div>
        <nav className="space-y-2">
          <Button variant="ghost" className="w-full">
            <FileText className="mr-2 h-4 w-4" />
            Todos los documentos
          </Button>
          <Button variant="ghost" className="w-full">
            <FilePlus className="mr-2 h-4 w-4" />
            Crear documento
          </Button>
          <Button variant="ghost" className="w-full">
            <Folder className="mr-2 h-4 w-4" />
            Control de versiones
          </Button>
          <Button variant="ghost" className="w-full">
            <Users className="mr-2 h-4 w-4" />
            Info de usuario
          </Button>
          <Button variant="ghost" className="w-full">
            <BarChart className="mr-2 h-4 w-4" />
            Reportes
          </Button>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8">
        <h1 className="mb-6 text-3xl font-bold">Administrador de Documentos</h1>

        {/* Document Cards */}
        <div className="mb-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Informe Q1.pdf</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Created: 2023-04-01</p>
              <p>Modified: 2023-04-15</p>
              <p>Type: PDF</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Presupuesto 2023.xlsx</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Created: 2023-03-20</p>
              <p>Modified: 2023-04-02</p>
              <p>Type: Excel</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Contrato.docx</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Created: 2023-04-01</p>
              <p>Modified: 2023-04-02</p>
              <p>Type: Word</p>
            </CardContent>
          </Card>
        </div>

        {/* Document Viewer and Versions */}
        <Tabs defaultValue="viewer" className="w-full">
          <TabsList>
            <TabsTrigger value="viewer">Document Viewer</TabsTrigger>
            <TabsTrigger value="versions">Document Versions</TabsTrigger>
          </TabsList>
          <TabsContent value="viewer">
            <Card>
              <CardHeader>
                <CardTitle>Document Viewer</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-96 w-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                  <p className="text-gray-500 dark:text-gray-400">Document preview would be displayed here</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="versions">
            <Card>
              <CardHeader>
                <CardTitle>Document Versions</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li>Version 1.0 - Created on 2023-04-01</li>
                  <li>Version 1.1 - Modified on 2023-04-02</li>
                  <li>Version 1.2 - Modified on 2023-04-15</li>
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}